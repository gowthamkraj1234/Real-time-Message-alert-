const axios = require('axios');

async function sendPanic() {
  const panicData = {
    userId: '123',
    message: 'panic',
    timestamp: new Date().toISOString(), // UTC timestamp
    location: {
      latitude: 37.7749,      // Sample coordinates
      longitude: -122.4194
    }
  };

  try {
    const response = await axios.post('http://localhost:3000/panic', panicData);
    console.log('Panic sent:', response.data);
  } catch (error) {
    console.error('Error sending panic:', error.message);
  }
}

sendPanic();
