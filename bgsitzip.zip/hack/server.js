const express = require('express');
const app = express();
const path = require('path');
const cors = require('cors');

const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const alerts = [];

app.post('/panic', (req, res) => {
  const alert = {
    ...req.body,
    serverReceivedAt: new Date().toISOString()
  };
  alerts.push(alert);
  console.log("📩 Alert received:", alert);
  res.send("Alert received!");
});

app.get('/alerts', (req, res) => {
  res.json(alerts);
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
